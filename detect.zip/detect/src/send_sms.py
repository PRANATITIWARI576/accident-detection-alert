import json
from twilio.rest import Client

def send_sms_alert():
    # Load Twilio credentials
    with open("../config/twilio_config.json", "r") as file:
        config = json.load(file)

    client = Client(config["account_sid"], config["auth_token"])

    for hospital_number in config["hospital_numbers"]:
        message = client.messages.create(
            body="Accident detected! Please send assistance immediately.",
            from_=config["twilio_number"],
            to=hospital_number
        )
        print(f"Alert sent to {hospital_number}. Message SID: {message.sid}")
