import random
import time

def track_vehicle(interval):
    # Simulate tracking GPS coordinates at regular intervals
    print(f"Tracking vehicle... (Interval: {interval} seconds)")
    while True:
        latitude = random.uniform(-90, 90)  # Simulate latitude
        longitude = random.uniform(-180, 180)  # Simulate longitude
        print(f"Current GPS coordinates: Latitude {latitude:.6f}, Longitude {longitude:.6f}")
        detect_accident()  # Check if an accident occurs
        time.sleep(interval)  # Wait for the specified interval

def detect_accident():
    # Simulate an abrupt stop or accident detection
    acceleration = random.uniform(0, 10)  # Simulated acceleration value
    threshold = 8  # Example threshold for detecting an accident
    if acceleration > threshold:
        print("Accident detected! Sending emergency alert...")
        send_emergency_alert()
    else:
        print("Normal driving...")

def send_emergency_alert():
    # Replace with actual notification logic (SMS, email, etc.)
    print("Emergency alert sent with GPS coordinates!")

if __name__ == "__main__":
    try:
        track_vehicle(interval=5)  # Start vehicle tracking
    except KeyboardInterrupt:
        print("\nTracking stopped.")
