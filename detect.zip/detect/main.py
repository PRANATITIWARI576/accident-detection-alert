import os
from accident_detection import detect_accident
from send_sms import send_sms_alert


def main():
    video_path = os.path.join("..", "data", "accident_sample.mp4")

    if detect_accident(video_path):
        print("Accident detected!")
        send_sms_alert()
    else:
        print("No accident detected.")


if __name__ == "__main__":
    main()
